package com.zensar.bus.exception;

public class SeatUnavailableException extends RuntimeException {

}
