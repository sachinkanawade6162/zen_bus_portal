package com.zensar.bus.exception;

public class UserNotfoundException extends RuntimeException {

}
