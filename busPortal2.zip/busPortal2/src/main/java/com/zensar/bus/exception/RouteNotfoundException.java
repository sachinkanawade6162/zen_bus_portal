package com.zensar.bus.exception;

public class RouteNotfoundException extends RuntimeException {

}
