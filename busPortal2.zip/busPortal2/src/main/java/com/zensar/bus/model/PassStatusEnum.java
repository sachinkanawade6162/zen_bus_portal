package com.zensar.bus.model;

public enum PassStatusEnum {

	Approved,Cancelled,Rejected,Pending; 
}
